# LKS NATIONAL COMPETITION — CLOUD COMPUTING
## TechnoDev DevOps CI/CD Platform
### GitHub Self-Hosted Runners + WebSocket Real-Time API on AWS

**Level**: National | **Year**: 2026 | **Field**: Cloud Computing

---

| Duration | Difficulty | Platform | Region |
|----------|------------|----------|--------|
| **5 Hours** | **Hard** | **AWS Academy Learner Lab + GitHub** | **us-west-2** |

> All AWS resources must use the prefix **`devops-`** and IAM Role **LabRole**. Creating new IAM roles is not permitted.

---

## 1. BACKGROUND

TechnoDev is a growing e-commerce platform that needs a reliable CI/CD pipeline to deploy
microservices automatically. The engineering team wants to use **GitHub Actions with
self-hosted runners** running on EC2 instances inside a private VPC, because AWS Academy
Learner Lab does not provide CodePipeline or CodeBuild.

You are assigned as the **DevOps Engineer** tasked with designing and building the
**TechnoDev DevOps CI/CD Platform** — a complete end-to-end DevOps infrastructure on AWS
that includes: a secure VPC with public and private subnets; EC2 instances as GitHub
Actions self-hosted runners; RDS PostgreSQL for data persistence; SQS and SNS for
event-driven messaging; four containerized Lambda functions (three behind a REST API
Gateway and one behind WebSocket API Gateway); GitHub Actions workflows for CI/CD
automation; a SPA frontend deployed via AWS Amplify with real-time WebSocket support;
and comprehensive monitoring with CloudWatch and VPC Flow Logs.

---

## 2. TASK LIST

| No | Task | Phase | Est. Time |
|----|------|-------|-----------|
| 1 | Create GitHub repository with branch protection and .gitignore | Phase 1 | 10 min |
| 2 | Provision VPC `devops-vpc` (210.0.0.0/16) with 4 subnets (2 public, 2 private) | Phase 1 | 15 min |
| 3 | Create Internet Gateway, NAT Gateway (Elastic IP), and route tables | Phase 1 | 15 min |
| 4 | Create 4 security groups: runners, lambda, rds, and default (least privilege) | Phase 1 | 10 min |
| 5 | Launch 2 EC2 instances (t3.medium) in private subnets with LabRole | Phase 2 | 15 min |
| 6 | Install Docker, AWS CLI, and GitHub Actions runner on both instances | Phase 2 | 15 min |
| 7 | Register runners to GitHub repo and verify "Online" status | Phase 2 | 10 min |
| 8 | Create `test-runner.yaml` workflow from scratch to validate runners | Phase 2 | 10 min |
| 9 | Create RDS PostgreSQL `devops-db` (db.t3.small, Multi-AZ) with 5 tables | Phase 3 | 20 min |
| 10 | Create 3 SQS queues: orders, notifications, and dead letter queue | Phase 3 | 10 min |
| 11 | Create 2 SNS topics: notifications and alerts | Phase 3 | 5 min |
| 12 | Create 4 ECR repositories and build/push container images | Phase 3 | 15 min |
| 13 | Deploy 4 Lambda functions (container images) with VPC configuration | Phase 3 | 20 min |
| 14 | Create API Gateway REST API `devops-api` with /users, /orders, and /products resources | Phase 4 | 20 min |
| 15 | Create API Gateway WebSocket API `devops-ws-api` with 4 routes | Phase 4 | 15 min |
| 16 | Deploy SPA frontend to AWS Amplify `devops-frontend` | Phase 4 | 10 min |
| 17 | Verify frontend 4 tabs: Products, Users, Orders, Real-Time | Phase 4 | 10 min |
| 18 | Create `ci.yaml` workflow from scratch: lint, build, test on pull request | Phase 5 | 15 min |
| 19 | Create `deploy.yaml` workflow from scratch: build, push ECR, update Lambda, deploy Amplify | Phase 5 | 20 min |
| 20 | Store RDS credentials in Secrets Manager `devops/rds-credentials` | Phase 6 | 10 min |
| 21 | Create CloudWatch dashboard with Lambda and RDS metrics | Phase 6 | 10 min |
| 22 | Enable VPC Flow Logs to CloudWatch Logs | Phase 6 | 10 min |
| 23 | Run end-to-end test: create user, create order, verify notification | Phase 7 | 15 min |
| 24 | Test WebSocket real-time: connect, update order status, verify broadcast | Phase 7 | 15 min |

---

## 3. SYSTEM ARCHITECTURE

![TechnoDev DevOps CI/CD Platform Architecture](arsitektur%20diagram.png)

*Figure 1. TechnoDev DevOps CI/CD Platform — End-to-End Architecture*

The platform is built on six interconnected layers. The **Network Layer** provides a
secure VPC with public subnets hosting NAT Gateway for outbound internet access, and
private subnets housing EC2 runners and Lambda functions. The **Compute Layer** uses
two EC2 instances as GitHub Actions self-hosted runners for CI/CD execution, and four
Lambda functions (container images from ECR) for application logic. The **Data Layer**
consists of RDS PostgreSQL Multi-AZ for persistent storage with 5 tables, SQS for
asynchronous order processing with a dead letter queue, and SNS for notifications.
The **API Layer** exposes a REST API Gateway for CRUD operations on users, orders,
and the read-only product catalog, plus a WebSocket API Gateway for real-time event
broadcasting. The
**Frontend Layer** hosts a Single Page Application on AWS Amplify with four tabs:
Products, Users, Orders, and Real-Time WebSocket event feed. The **Observability Layer**
provides CloudWatch dashboards, alarms, and VPC Flow Logs for network traffic analysis.

```
+---------------------------------------------------------------------------------+
|  FRONTEND LAYER                                                                 |
|                                                                                 |
|  AWS Amplify (devops-frontend) — SPA Dashboard                                  |
|       |                       4 Tabs: Products | Users | Orders | Real-Time     |
|       v                                                                         |
+-------+-------------------------------------------------------------------------+
        |                                           |
        v (HTTPS)                                   v (WebSocket)
+-------------------------------+   +------------------------------------------+
|  REST API Gateway             |   |  WebSocket API Gateway                   |
|  (devops-api)                 |   |  (devops-ws-api)                         |
|                               |   |                                          |
|  ANY /users, /users/{proxy+}  |   |  $connect → Lambda                      |
|  ANY /orders, /orders/{proxy+}|   |  $disconnect → Lambda                   |
|  ANY /products/{proxy+}       |   |  $default → Lambda                      |
|  (Lambda Proxy integration)   |   |  sendMessage → Lambda                   |
+-------------------------------+   +------------------------------------------+
        |                                           |
        v                                           v
+---------------------------------------------------------------------------------+
|  LAMBDA FUNCTIONS (Container Images from ECR)                                   |
|                                                                                 |
|  devops-user-api      devops-order-api      devops-websocket-api                |
|  (512MB, 30s)         (512MB, 30s)          (512MB, 30s)                        |
|       |                    | (also serves /products)                          |
|       |                    v                      v                              |
|       |              SQS (devops-orders-queue)   DynamoDB? / Broadcast           |
|       |                    |                                                    |
|       |                    v                                                     |
|       |         devops-notif-worker (256MB, 60s)                                |
|       |                    |                                                    |
|       v                    v                                                    |
|  +-------------------------------------------------------------------+          |
|  |  RDS PostgreSQL (devops-db) — Multi-AZ                            |          |
|  |  devopsdb: users, products, orders, notifications, ws_connections |          |
|  +-------------------------------------------------------------------+          |
+---------------------------------------------------------------------------------+

+---------------------------------------------------------------------------------+
|  MESSAGING LAYER                                                                |
|                                                                                 |
|  SQS: devops-orders-queue → devops-notif-worker → SNS: devops-notifications    |
|  SQS: devops-notifications-queue (consumer-driven)                              |
|  SQS: devops-dlq (dead letter queue, maxReceiveCount: 3)                        |
|  SNS: devops-alerts (CloudWatch alarm actions)                                  |
+---------------------------------------------------------------------------------+

+---------------------------------------------------------------------------------+
|  CI/CD PIPELINE (GitHub Actions on Self-Hosted Runners)                         |
|                                                                                 |
|  Pull Request → ci.yaml: flake8 lint → Docker build → handler import test      |
|  Push to main → deploy.yaml: build → push ECR → update Lambda → Amplify        |
|                                                                                 |
|  EC2 Runner 01 (t3.medium, private subnet, us-west-2a)                          |
|  EC2 Runner 02 (t3.medium, private subnet, us-west-2b)                          |
+---------------------------------------------------------------------------------+

+---------------------------------------------------------------------------------+
|  OBSERVABILITY                                                                  |
|                                                                                 |
|  CloudWatch Dashboard: Lambda metrics + RDS metrics                             |
|  VPC Flow Logs → CloudWatch Logs (/aws/vpc/devops-vpc/flowlogs)                 |
|  Secrets Manager: devops/rds-credentials                                        |
+---------------------------------------------------------------------------------+
```

### AWS Services Map

| Layer | Service | Role |
|-------|---------|------|
| Network | Amazon VPC | Isolated network with public and private subnets |
| Network | Internet Gateway | Public internet access for public subnets |
| Network | NAT Gateway | Outbound internet for private subnets (runners, Lambda) |
| Compute | Amazon EC2 | Self-hosted GitHub Actions runners (2× t3.medium) |
| Compute | AWS Lambda | 4 containerized functions for API and event processing |
| Compute | Amazon ECR | Container image registry for Lambda functions |
| Data | Amazon RDS PostgreSQL | Relational database with 5 tables, Multi-AZ |
| Data | Amazon SQS | Message queues for order processing and dead letters |
| Data | Amazon SNS | Notification topics for alerts and user notifications |
| API | API Gateway (REST) | REST endpoints for /users, /orders, /products CRUD |
| API | API Gateway (WebSocket) | Real-time bidirectional communication |
| Frontend | AWS Amplify | SPA hosting with 4-tab dashboard |
| Security | AWS Secrets Manager | Secure RDS credential storage |
| Security | Security Groups | Network-level access control (least privilege) |
| Observability | Amazon CloudWatch | Dashboard, metrics, alarms, and logs |
| Observability | VPC Flow Logs | Network traffic analysis and auditing |
| CI/CD | GitHub Actions | Automated lint, build, test, deploy pipelines |

---

## 4. DATA MODELS

### users (3 seed records)

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key, auto-generated |
| username | VARCHAR(50) | Unique username |
| email | VARCHAR(100) | Unique email address |
| full_name | VARCHAR(100) | User's full name |
| phone | VARCHAR(20) | Phone number (nullable) |
| address | TEXT | Mailing address (nullable) |
| created_at | TIMESTAMP WITH TIME ZONE | Record creation time |
| updated_at | TIMESTAMP WITH TIME ZONE | Last update time |

### products (5 seed records)

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key, auto-generated |
| sku | VARCHAR(50) | Unique stock keeping unit |
| name | VARCHAR(200) | Product name |
| description | TEXT | Product description (nullable) |
| price | NUMERIC(12,2) | Product price in IDR (≥ 0) |
| stock | INTEGER | Available stock (≥ 0) |
| category | VARCHAR(100) | Product category |
| created_at | TIMESTAMP WITH TIME ZONE | Record creation time |
| updated_at | TIMESTAMP WITH TIME ZONE | Last update time |

### orders

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key, auto-generated |
| user_id | UUID | Foreign key → users(id), ON DELETE CASCADE |
| product_id | UUID | Foreign key → products(id), ON DELETE RESTRICT |
| quantity | INTEGER | Order quantity (> 0) |
| total_price | NUMERIC(12,2) | Total order price (≥ 0) |
| status | VARCHAR(20) | pending / processing / shipped / delivered / cancelled |
| shipping_address | TEXT | Delivery address (nullable) |
| notes | TEXT | Order notes (nullable) |
| created_at | TIMESTAMP WITH TIME ZONE | Record creation time |
| updated_at | TIMESTAMP WITH TIME ZONE | Last update time |

### notifications

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key, auto-generated |
| user_id | UUID | Foreign key → users(id), ON DELETE CASCADE |
| order_id | UUID | Foreign key → orders(id), ON DELETE SET NULL |
| type | VARCHAR(50) | Notification type |
| message | TEXT | Notification content |
| channel | VARCHAR(20) | email / sms / push |
| status | VARCHAR(20) | pending / sent / failed / read |
| sent_at | TIMESTAMP WITH TIME ZONE | Time notification was sent (nullable) |
| created_at | TIMESTAMP WITH TIME ZONE | Record creation time |

### ws_connections

| Column | Type | Description |
|--------|------|-------------|
| connection_id | VARCHAR(100) | Primary key (WebSocket connection ID) |
| user_id | UUID | Foreign key → users(id), ON DELETE SET NULL |
| username | VARCHAR(50) | Username associated with connection |
| route_key | VARCHAR(20) | WebSocket route key (default: $default) |
| connected_at | TIMESTAMP WITH TIME ZONE | Connection establishment time |

---

## 5. TECHNICAL SPECIFICATIONS

| Component | Specification |
|-----------|---------------|
| VPC | CIDR: `210.0.0.0/16`, DNS support enabled, DNS hostnames enabled |
| Public Subnet 1 | CIDR: `210.0.1.0/24`, AZ: us-west-2a, auto-assign public IP |
| Public Subnet 2 | CIDR: `210.0.2.0/24`, AZ: us-west-2b, auto-assign public IP |
| Private Subnet 1 | CIDR: `210.0.10.0/24`, AZ: us-west-2a |
| Private Subnet 2 | CIDR: `210.0.11.0/24`, AZ: us-west-2b |
| NAT Gateway | Single NAT in public subnet 1, Elastic IP attached |
| EC2 Runners | 2× t3.medium, Amazon Linux 2023, private subnets, LabRole instance profile |
| RDS PostgreSQL | db.t3.small, Multi-AZ, 20GB gp3, database name: `devopsdb`, port 5432 |
| RDS Credentials | Admin user: `devopsadmin`, password stored in Secrets Manager |
| SQS — orders-queue | Standard queue, visibility timeout 30s, message retention 4 days |
| SQS — notifications-queue | Standard queue, visibility timeout 60s, message retention 4 days |
| SQS — dlq | Dead letter queue, visibility timeout 60s, message retention 14 days |
| SQS Redrive Policy | maxReceiveCount: 3 (messages sent to DLQ after 3 failed attempts) |
| SNS — notifications | Standard topic, email subscription for order notifications |
| SNS — alerts | Standard topic, email subscription for system alerts |
| ECR Repositories | 4 repos: `devops/user-api`, `devops/order-api`, `devops/notif-worker`, `devops/websocket-api` |
| Lambda — user-api | Container image, 512 MB, 30s timeout, VPC config (private subnets) |
| Lambda — order-api | Container image, 512 MB, 30s timeout, VPC config (private subnets), also serves /products |
| Lambda — notif-worker | Container image, 256 MB, 60s timeout, SQS trigger (notifications-queue) |
| Lambda — websocket-api | Container image, 512 MB, 30s timeout, WebSocket API integration |
| Lambda Runtime | Python 3.11 (container image: `public.ecr.aws/lambda/python:3.11`) |
| REST API Gateway | Name: `devops-api`, endpoint type: REGIONAL, stage: `prod`, resources: /users, /orders, /products (Lambda proxy) |
| WebSocket API Gateway | Name: `devops-ws-api`, routes: $connect, $disconnect, $default, sendMessage |
| Amplify | App name: `devops-frontend`, branch: `main`, platform: WEB |
| CloudWatch Dashboard | Name: `devops-dashboard`, Lambda invocations/errors + RDS CPU/connections |
| VPC Flow Logs | Destination: CloudWatch Logs, log group: `/aws/vpc/devops-vpc/flowlogs` |
| Secrets Manager | Secret: `devops/rds-credentials`, keys: host, port, dbname, username, password |
| GitHub Repository | Name: `devops-learner-lab`, branch protection on `main`, require PR review |

---

## 6. INSTRUCTIONS

> **⚠️ IMPORTANT**: This module focuses on **DevOps engineering**. Application source code (Lambda handlers, Dockerfiles, SQL schema, and frontend) are **provided in the repository** — clone it and deploy. GitHub Actions workflow files are **provided in this document** — copy them into your repository. You must **build all AWS infrastructure from scratch** (VPC, EC2, RDS, SQS, SNS, ECR, Lambda, API Gateway, Amplify, CloudWatch) and ensure the entire CI/CD pipeline works end-to-end.

### Phase 1 — Foundation & Network (±50 minutes)

**Task 1 — GitHub Repository**

Create a new GitHub repository named `devops-learner-lab`. Initialize it with a `README.md` and a `.gitignore` file configured for Python. Enable branch protection on the `main` branch requiring at least one pull request review before merging. Clone the repository to your working environment (AWS CloudShell or local machine). Ensure all required CLI tools are available: `aws`, `docker`, `git`, `curl`. Export all required environment variables for subsequent tasks.

```bash
# Verify credentials
aws sts get-caller-identity

# Set environment
export AWS_REGION="us-west-2"
export ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
export ECR_REGISTRY="${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
export PREFIX="devops"
```

**Task 2 — VPC**

Provision VPC `devops-vpc` with CIDR block `210.0.0.0/16`. Enable DNS support and DNS hostnames on the VPC. Create four subnets: public subnet 1 (`210.0.1.0/24` in us-west-2a), public subnet 2 (`210.0.2.0/24` in us-west-2b), private subnet 1 (`210.0.10.0/24` in us-west-2a), and private subnet 2 (`210.0.11.0/24` in us-west-2b). Enable auto-assign public IPv4 address on both public subnets.

**Task 3 — Internet Gateway, NAT Gateway, Route Tables**

Create an Internet Gateway and attach it to `devops-vpc`. Allocate an Elastic IP and create a NAT Gateway in public subnet 1. Create a public route table with a default route (`0.0.0.0/0`) pointing to the Internet Gateway, and associate it with both public subnets. Create a private route table with a default route (`0.0.0.0/0`) pointing to the NAT Gateway, and associate it with both private subnets. Verify that instances in private subnets can reach the internet through the NAT Gateway.

**Task 4 — Security Groups**

Create four security groups within `devops-vpc` following the principle of least privilege:

| Security Group | Name | Inbound Rules | Purpose |
|---------------|------|---------------|---------|
| Runners SG | `devops-sg-runners` | Self-referencing (all traffic within group) | GitHub Actions runner inter-communication |
| Lambda SG | `devops-sg-lambda` | No inbound (outbound only) | Lambda functions in VPC |
| RDS SG | `devops-sg-rds` | Port 5432 from `devops-sg-lambda`; Port 5432 from `devops-sg-runners` | PostgreSQL access |
| Default SG | `devops-sg-default` | Self-referencing (all traffic within group) | General internal traffic |

All security groups must allow all outbound traffic by default. The RDS security group must only accept PostgreSQL connections (port 5432) from Lambda functions and EC2 runners — no public access.

---

### Phase 2 — Self-Hosted Runners (±50 minutes)

**Task 5 — EC2 Instances**

Launch two EC2 instances of type `t3.medium` using Amazon Linux 2023 AMI, placed in the two private subnets (one per AZ). Attach the `LabRole` instance profile (IAM role) to both instances. Tag them as `devops-runner-01` and `devops-runner-02`. Assign the `devops-sg-runners` security group. Ensure both instances have outbound internet access via the NAT Gateway for downloading packages and communicating with GitHub.

**Task 6 — Software Installation**

Connect to each EC2 instance via AWS Systems Manager Session Manager (since they are in private subnets without public IPs). Install the following software on both instances:

- **Docker Engine** — for building and running container images
- **AWS CLI v2** — for interacting with AWS services
- **GitHub Actions Runner** — latest version from `https://github.com/actions/runner`
- **Git** — for repository operations

Verify each installation:
```bash
docker --version        # Docker Engine 24.x+
aws --version           # aws-cli/2.x
git --version           # git 2.x
```

**Task 7 — Runner Registration**

Register both EC2 instances as self-hosted runners in the GitHub repository `devops-learner-lab`. Use a GitHub Personal Access Token (PAT) with `repo` and `admin:org` scopes to obtain a registration token. Configure the runner with the following settings:

- **Labels**: `self-hosted`, `linux`, `x64`
- **Runner Group**: Default
- **Work Directory**: `_work`

Start the runner as a service so it persists across reboots. Verify that both runners appear as "Online" (idle) in the repository Settings → Actions → Runners page.

```bash
# On each EC2 instance:
./config.sh --url https://github.com/{owner}/devops-learner-lab \
  --token {REGISTRATION_TOKEN} \
  --labels self-hosted,linux,x64 \
  --unattended

sudo ./svc.sh install
sudo ./svc.sh start
```

**Task 8 — Runner Verification Workflow**

Create the file `.github/workflows/test-runner.yaml` in your repository with the following content:

```yaml
name: Test Runner

on:
  workflow_dispatch:

jobs:
  verify-runner:
    runs-on: self-hosted
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Print runner info
        run: |
          echo "=== Runner Environment ==="
          echo "Hostname:     $(hostname)"
          echo "OS:           $(uname -a)"
          echo "User:         $(whoami)"
          echo "Working Dir:  $(pwd)"
          echo "CPU Cores:    $(nproc)"
          echo "Memory:"
          free -h
          echo "Disk:"
          df -h /
          echo "=========================="

      - name: Verify Docker
        run: |
          echo "=== Docker Verification ==="
          docker --version
          docker run --rm hello-world
          echo "Docker is working correctly!"
          echo "==========================="

      - name: Verify AWS CLI
        run: |
          echo "=== AWS CLI Verification ==="
          aws --version
          aws sts get-caller-identity
          echo "AWS Region: ${AWS_REGION:-us-west-2}"
          echo "AWS CLI is configured correctly!"
          echo "============================="

      - name: Verify Git
        run: |
          echo "=== Git Verification ==="
          git --version
          echo "Git is available!"
          echo "======================"
```

Push to your repository, trigger the workflow manually from the GitHub Actions tab, and confirm it completes successfully on your self-hosted runners.

---

### Phase 3 — Application Infrastructure (±70 minutes)

**Task 9 — RDS PostgreSQL**

Create an RDS DB Subnet Group named `devops-subnet-group` using both private subnets. Create an RDS PostgreSQL instance with the following configuration:

| Parameter | Value |
|-----------|-------|
| DB Instance Identifier | `devops-db` |
| Engine | PostgreSQL 15 |
| Instance Class | db.t3.small |
| Storage | 20 GB gp3 |
| Multi-AZ | Yes |
| Database Name | `devopsdb` |
| Master Username | `devopsadmin` |
| Master Password | (secure, store in Secrets Manager) |
| VPC Security Group | `devops-sg-rds` |
| Public Access | No |
| Backup Retention | 7 days |
| Encryption | Enabled (AWS managed key) |

Once the RDS instance is available, connect using the runner EC2 instance and execute the provided `sql/schema.sql` script to create all 5 tables (users, products, orders, notifications, ws_connections), indexes, stored procedures, and seed data.

```bash
psql -h {rds-endpoint} -U devopsadmin -d devopsdb -f sql/schema.sql
```

**Task 10 — SQS Queues**

Create three SQS Standard queues:

| Queue Name | Visibility Timeout | Message Retention | Redrive Policy |
|------------|-------------------|-------------------|----------------|
| `devops-orders-queue` | 30 seconds | 4 days | DLQ: `devops-dlq`, maxReceiveCount: 3 |
| `devops-notifications-queue` | 60 seconds | 4 days | DLQ: `devops-dlq`, maxReceiveCount: 3 |
| `devops-dlq` | 60 seconds | 14 days | None (terminal queue) |

Create the dead letter queue first, then create the other two queues with redrive policies pointing to `devops-dlq`. Verify all three queues are active by sending and receiving a test message.

**Task 11 — SNS Topics**

Create two SNS Standard topics:

| Topic Name | Purpose | Subscription |
|-----------|---------|--------------|
| `devops-notifications` | Order status notifications | Email (participant's address) |
| `devops-alerts` | System alerts and CloudWatch alarms | Email (participant's address) |

Confirm both email subscriptions via the confirmation link. Verify by publishing a test message to each topic and confirming receipt in the inbox.

**Task 12 — ECR Repositories & Container Images**

Create four ECR repositories with image scanning on push enabled and mutable image tags:

| Repository Name | Lambda Function | Base Image |
|----------------|-----------------|------------|
| `devops/user-api` | devops-user-api | `public.ecr.aws/lambda/python:3.11` |
| `devops/order-api` | devops-order-api | `public.ecr.aws/lambda/python:3.11` |
| `devops/notif-worker` | devops-notif-worker | `public.ecr.aws/lambda/python:3.11` |
| `devops/websocket-api` | devops-websocket-api | `public.ecr.aws/lambda/python:3.11` |

Build each Docker image using the Dockerfile in the respective `lambda/` subdirectory. Push all images with the `latest` tag to their ECR repositories.

```bash
# Login to ECR
aws ecr get-login-password --region us-west-2 | \
  docker login --username AWS --password-stdin ${ECR_REGISTRY}

# Build and push each image
docker build -t ${ECR_REGISTRY}/devops/user-api:latest lambda/user-api/
docker push ${ECR_REGISTRY}/devops/user-api:latest
# Repeat for order-api, notification-worker, websocket-api
```

**Task 13 — Lambda Functions**

Deploy four Lambda functions using container images from ECR. All functions must be configured with VPC access (both private subnets + `devops-sg-lambda` security group) and LabRole execution role.

| Function Name | Image URI | Memory | Timeout | Trigger |
|--------------|-----------|--------|---------|---------|
| `devops-user-api` | `{account}.dkr.ecr.us-west-2.amazonaws.com/devops/user-api:latest` | 512 MB | 30s | REST API |
| `devops-order-api` | `{account}.dkr.ecr.us-west-2.amazonaws.com/devops/order-api:latest` | 512 MB | 30s | REST API |
| `devops-notif-worker` | `{account}.dkr.ecr.us-west-2.amazonaws.com/devops/notif-worker:latest` | 256 MB | 60s | SQS |
| `devops-websocket-api` | `{account}.dkr.ecr.us-west-2.amazonaws.com/devops/websocket-api:latest` | 512 MB | 30s | WebSocket API |

Configure the following environment variables on each Lambda function:

| Variable | Value | Functions |
|----------|-------|-----------|
| `DB_HOST` | RDS endpoint | All 4 |
| `DB_PORT` | `5432` | All 4 |
| `DB_NAME` | `devopsdb` | All 4 |
| `DB_USER` | `devopsadmin` | All 4 |
| `DB_PASSWORD` | RDS password | All 4 |
| `SQS_ORDER_QUEUE_URL` | Orders queue URL | order-api |
| `SQS_NOTIFICATION_QUEUE_URL` | Notifications queue URL | order-api, notif-worker |
| `SNS_NOTIFICATIONS_TOPIC_ARN` | Notifications topic ARN | notif-worker |
| `WEBSOCKET_API_ENDPOINT` | WebSocket API callback URL | websocket-api |

Add an SQS event source mapping on `devops-notif-worker` pointing to `devops-notifications-queue` with batch size 10. Perform a test invocation on each function to verify database connectivity.

---

### Phase 4 — API Gateway & Frontend (±50 minutes)

**Task 14 — REST API Gateway**

Create an API Gateway **REST API** (`apigateway create-rest-api`, not the HTTP API / apigatewayv2 flavor) named `devops-api` with a REGIONAL endpoint configuration. Under the API's root resource, create three child resources — `/users`, `/orders`, and `/products` — and under each of those, a greedy `{proxy+}` child resource so that sub-paths such as `/users/{id}` are also routed to the same Lambda function. Define the following methods and integrations:

| Resource | Method | Integration | Lambda Function |
|----------|--------|-------------|-----------------|
| `/users` | ANY | Lambda Proxy (AWS_PROXY) | devops-user-api |
| `/users/{proxy+}` | ANY | Lambda Proxy (AWS_PROXY) | devops-user-api |
| `/orders` | ANY | Lambda Proxy (AWS_PROXY) | devops-order-api |
| `/orders/{proxy+}` | ANY | Lambda Proxy (AWS_PROXY) | devops-order-api |
| `/products` | ANY | Lambda Proxy (AWS_PROXY) | devops-order-api |
| `/products/{proxy+}` | ANY | Lambda Proxy (AWS_PROXY) | devops-order-api |

The `/products` resource is a read-only product catalog and is served by the same `devops-order-api` Lambda function (it already holds the database connection needed to query the `products` table). Grant `apigateway.amazonaws.com` permission to invoke each Lambda function with a `lambda add-permission` source ARN scoped to `arn:aws:execute-api:{region}:{account-id}:{api-id}/*/*/{resource}*`.

Since the REST API does not auto-generate CORS like the HTTP API does, add an `OPTIONS` method with a `MOCK` integration on every resource above, returning the headers `Access-Control-Allow-Origin: *`, `Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS`, and `Access-Control-Allow-Headers: Content-Type,Authorization`.

Create a deployment (`aws apigateway create-deployment`) targeting a stage named `prod`. Re-deploy after any resource or method change — unlike the HTTP API's auto-deploy stages, REST API stages only pick up changes on an explicit deployment. Verify the API is accessible:

```bash
API_URL="https://{api-id}.execute-api.us-west-2.amazonaws.com/prod"
curl -s "${API_URL}/users" | jq .
curl -s "${API_URL}/products" | jq .
```

**Task 15 — WebSocket API Gateway**

Create an API Gateway WebSocket API named `devops-ws-api`. Define the following routes integrated with Lambda function `devops-websocket-api`:

| Route Key | Description | Integration |
|-----------|-------------|-------------|
| `$connect` | Client connection handler | Lambda Proxy → devops-websocket-api |
| `$disconnect` | Client disconnection handler | Lambda Proxy → devops-websocket-api |
| `$default` | Default message handler | Lambda Proxy → devops-websocket-api |
| `sendMessage` | Custom action for broadcasting | Lambda Proxy → devops-websocket-api |

Deploy to a stage named `prod`. The WebSocket API supports the following actions sent as JSON messages:

| Action | Description | Response |
|--------|-------------|----------|
| `ping` | Health check | `{"action": "pong", "timestamp": "..."}` |
| `get_connections` | List active WebSocket connections | Array of connection records |
| `get_orders` | Retrieve orders in real-time | Array of order records from database |
| `order_status_update` | Update order status and broadcast | Broadcasts new status to all connected clients |
| `send_notification` | Send notification to user(s) | Broadcasts notification message |

Verify WebSocket connectivity using `wscat`:
```bash
wscat -c "wss://{ws-api-id}.execute-api.us-west-2.amazonaws.com/prod"
> {"action": "ping"}
< {"action": "pong", "timestamp": "..."}
```

**Task 16 — AWS Amplify Frontend**

Create an Amplify app named `devops-frontend` with platform type WEB. Create a branch named `main` with stage set to PRODUCTION. Package the provided `frontend/index.html` file into a zip archive and deploy it using Amplify's manual deployment method:

1. Create a deployment using `aws amplify create-deployment`
2. Upload the zip file to the pre-signed URL returned by the API
3. Start the deployment using `aws amplify start-deployment`

Once the deployment status reaches SUCCEED, the frontend dashboard will be accessible at `https://main.{app-id}.amplifyapp.com`.

**Task 17 — Frontend Verification**

Open the deployed Amplify URL in a browser. The dashboard must display four functional tabs:

| Tab | Content | Data Source |
|-----|---------|-------------|
| **Products** | Read-only product table with stock badges | REST API: GET /products |
| **Users** | CRUD operations with modal dialogs | REST API: GET/POST/PUT/DELETE /users |
| **Orders** | CRUD operations with status badges and update modal | REST API: GET/POST/PUT/DELETE /orders |
| **Real-Time** | WebSocket event feed (dark terminal style), auto-reconnect, Ping/Connections/Clear buttons | WebSocket API |

Configure the frontend by entering the REST API Gateway URL and WebSocket API URL in the configuration panel. Verify that:
- Products tab shows 5 seed products with correct prices and stock
- Users tab allows create, edit, and delete operations
- Orders tab allows creating orders linked to existing users and products
- Real-Time tab connects to WebSocket and displays events as they occur

---

### Phase 5 — CI/CD Pipeline (±35 minutes)

> **Note**: You must **create all workflow files** by copying the code provided below into your repository. The application code (Lambda handlers, Dockerfiles, frontend, SQL) is already provided in the repository — your job is to set up the CI/CD automation.

**Task 18 — CI Workflow (ci.yaml)**

Create the file `.github/workflows/ci.yaml` in your repository with the following content:

```yaml
name: CI Pipeline

on:
  pull_request:
    branches: [main]

jobs:
  lint-and-test:
    runs-on: self-hosted
    env:
      AWS_REGION: us-west-2
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install linting tools
        run: pip install flake8

      - name: Python lint - user-api
        run: flake8 lambda/user-api/app.py --max-line-length=120 --ignore=E501,W503

      - name: Python lint - order-api
        run: flake8 lambda/order-api/app.py --max-line-length=120 --ignore=E501,W503

      - name: Python lint - notification-worker
        run: flake8 lambda/notification-worker/app.py --max-line-length=120 --ignore=E501,W503

      - name: Python lint - websocket-api
        run: flake8 lambda/websocket-api/app.py --max-line-length=120 --ignore=E501,W503

      - name: Build Docker image - user-api
        run: docker build -t devops/user-api:test lambda/user-api/

      - name: Build Docker image - order-api
        run: docker build -t devops/order-api:test lambda/order-api/

      - name: Build Docker image - notification-worker
        run: docker build -t devops/notif-worker:test lambda/notification-worker/

      - name: Build Docker image - websocket-api
        run: docker build -t devops/websocket-api:test lambda/websocket-api/

      - name: Test Lambda handler imports - user-api
        run: |
          docker run --rm devops/user-api:test \
            python -c "import app; print('user-api handler OK')"

      - name: Test Lambda handler imports - order-api
        run: |
          docker run --rm devops/order-api:test \
            python -c "import app; print('order-api handler OK')"

      - name: Test Lambda handler imports - notification-worker
        run: |
          docker run --rm devops/notif-worker:test \
            python -c "import app; print('notification-worker handler OK')"

      - name: Test Lambda handler imports - websocket-api
        run: |
          docker run --rm devops/websocket-api:test \
            python -c "import app; print('websocket-api handler OK')"

      - name: Verify frontend
        run: |
          test -f frontend/index.html
          grep -q "TechnoDev" frontend/index.html
          echo "Frontend content verified"

      - name: Verify SQL schema
        run: |
          test -f sql/schema.sql
          grep -q "CREATE TABLE" sql/schema.sql
          echo "SQL schema verified"

      - name: Cleanup test images
        if: always()
        run: |
          docker rmi devops/user-api:test devops/order-api:test devops/notif-worker:test devops/websocket-api:test 2>/dev/null || true
```

Create a feature branch, make a change, open a pull request to `main`, and verify the CI pipeline completes successfully on your self-hosted runners.

**Task 19 — CD Workflow (deploy.yaml)**

Create the file `.github/workflows/deploy.yaml` in your repository with the following content:

```yaml
name: Deploy Pipeline

on:
  push:
    branches: [main]

env:
  AWS_REGION: us-west-2
  PREFIX: devops

jobs:
  deploy:
    runs-on: self-hosted
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set environment variables
        run: |
          ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
          echo "ACCOUNT_ID=${ACCOUNT_ID}" >> $GITHUB_ENV
          echo "ECR_REGISTRY=${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com" >> $GITHUB_ENV

      - name: Login to Amazon ECR
        run: |
          aws ecr get-login-password --region ${AWS_REGION} | \
            docker login --username AWS --password-stdin ${ECR_REGISTRY}

      - name: Build and push all images
        run: |
          for svc in user-api order-api; do
            docker build -t ${ECR_REGISTRY}/${PREFIX}/${svc}:latest \
                         -t ${ECR_REGISTRY}/${PREFIX}/${svc}:${GITHUB_SHA::8} \
                         lambda/${svc}/
            docker push ${ECR_REGISTRY}/${PREFIX}/${svc}:latest
            docker push ${ECR_REGISTRY}/${PREFIX}/${svc}:${GITHUB_SHA::8}
          done
          docker build -t ${ECR_REGISTRY}/${PREFIX}/notif-worker:latest \
                       -t ${ECR_REGISTRY}/${PREFIX}/notif-worker:${GITHUB_SHA::8} \
                       lambda/notification-worker/
          docker push ${ECR_REGISTRY}/${PREFIX}/notif-worker:latest
          docker push ${ECR_REGISTRY}/${PREFIX}/notif-worker:${GITHUB_SHA::8}
          docker build -t ${ECR_REGISTRY}/${PREFIX}/websocket-api:latest \
                       -t ${ECR_REGISTRY}/${PREFIX}/websocket-api:${GITHUB_SHA::8} \
                       lambda/websocket-api/
          docker push ${ECR_REGISTRY}/${PREFIX}/websocket-api:latest
          docker push ${ECR_REGISTRY}/${PREFIX}/websocket-api:${GITHUB_SHA::8}

      - name: Update Lambda functions
        run: |
          for fn in user-api order-api notif-worker websocket-api; do
            aws lambda update-function-code \
              --function-name ${PREFIX}-${fn} \
              --image-uri ${ECR_REGISTRY}/${PREFIX}/${fn}:latest \
              --region ${AWS_REGION}
          done

      - name: Deploy frontend to Amplify
        run: |
          APP_ID=$(aws amplify list-apps --region ${AWS_REGION} \
            --query "apps[?name=='${PREFIX}-frontend'].appId" --output text)
          if [ -n "$APP_ID" ] && [ "$APP_ID" != "None" ]; then
            cd frontend && zip -r ../frontend.zip . && cd ..
            DEPLOYMENT=$(aws amplify create-deployment --app-id ${APP_ID} \
              --branch-name main --region ${AWS_REGION})
            UPLOAD_URL=$(echo $DEPLOYMENT | python3 -c "import sys,json; print(json.load(sys.stdin)['zipUploadUrl'])")
            JOB_ID=$(echo $DEPLOYMENT | python3 -c "import sys,json; print(json.load(sys.stdin)['jobId'])")
            curl -T frontend.zip "$UPLOAD_URL"
            aws amplify start-deployment --app-id ${APP_ID} --branch-name main \
              --job-id ${JOB_ID} --region ${AWS_REGION}
            rm -f frontend.zip
          fi

      - name: Smoke test
        run: |
          API_ID=$(aws apigateway get-rest-apis --region ${AWS_REGION} \
            --query "items[?name=='${PREFIX}-api'].id" --output text)
          if [ -n "$API_ID" ] && [ "$API_ID" != "None" ]; then
            API_URL="https://${API_ID}.execute-api.${AWS_REGION}.amazonaws.com/prod"
            curl -sf "${API_URL}/users" > /dev/null && echo "/users OK"
            curl -sf "${API_URL}/orders" > /dev/null && echo "/orders OK"
            curl -sf "${API_URL}/products" > /dev/null && echo "/products OK"
          fi
```

Merge the pull request into `main` to trigger the CD workflow. Verify that all 4 ECR repositories show new images, all Lambda functions are updated, Amplify is redeployed, and the smoke test passes.

---

### Phase 6 — Security & Observability (±30 minutes)

**Task 20 — Secrets Manager**

Store the RDS PostgreSQL credentials in AWS Secrets Manager to eliminate hardcoded passwords from Lambda environment variables. Create a secret named `devops/rds-credentials` of type "Other type of secret" containing the following key-value pairs:

| Key | Value |
|-----|-------|
| `host` | RDS endpoint hostname |
| `port` | `5432` |
| `dbname` | `devopsdb` |
| `username` | `devopsadmin` |
| `password` | (the RDS master password) |

After creating the secret, update all four Lambda functions to retrieve credentials at runtime using `boto3.client('secretsmanager').get_secret_value(SecretId='devops/rds-credentials')` instead of reading from environment variables. Remove the hardcoded `DB_PASSWORD` environment variable from all functions. Perform a test invocation on each function to confirm database connectivity still works.

**Task 21 — CloudWatch Dashboard**

Create a CloudWatch Dashboard named `devops-dashboard` displaying the following widgets:

| Widget | Type | Metrics |
|--------|------|---------|
| Lambda Invocations | Line chart | Invocations for all 4 Lambda functions |
| Lambda Errors | Line chart | Errors for all 4 Lambda functions |
| Lambda Duration | Line chart | Duration (p50, p99) for user-api and order-api |
| RDS CPU Utilization | Line chart | CPUUtilization for devops-db |
| RDS Database Connections | Line chart | DatabaseConnections for devops-db |
| SQS Messages | Bar chart | ApproximateNumberOfMessagesVisible for all 3 queues |

Verify that all widgets display data after performing several API calls and Lambda invocations.

**Task 22 — VPC Flow Logs**

Enable VPC Flow Logs on `devops-vpc` with the following configuration:

| Parameter | Value |
|-----------|-------|
| Traffic Type | ALL |
| Destination | CloudWatch Logs |
| Log Group | `/aws/vpc/devops-vpc/flowlogs` |
| IAM Role | LabRole |
| Log Format | Default |

Create the CloudWatch Logs log group before enabling flow logs. Verify that flow log records appear in CloudWatch Logs within 5 minutes of enabling. Generate traffic by making API calls and confirm the flow log entries show ACCEPT and REJECT actions.

---

### Phase 7 — End-to-End Verification (±30 minutes)

**Task 23 — CRUD End-to-End Test**

Perform a complete end-to-end test of the REST API by executing the following sequence:

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | `POST /users` with JSON body | HTTP 201, new user created |
| 2 | `GET /users` | HTTP 200, list includes new user |
| 3 | `POST /orders` with user_id and product_id | HTTP 201, new order created |
| 4 | `GET /orders` | HTTP 200, list includes new order |
| 5 | `PUT /orders/{id}` update status to "shipped" | HTTP 200, status updated |
| 6 | Verify notification in SQS/SNS | Notification sent to SNS topic |
| 7 | `DELETE /users/{id}` | HTTP 200, user deleted (cascade deletes orders) |

```bash
API_URL="https://{api-id}.execute-api.us-west-2.amazonaws.com/prod"

# Create user
curl -X POST "${API_URL}/users" \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@technodev.com","full_name":"Test User"}'

# Create order
curl -X POST "${API_URL}/orders" \
  -H "Content-Type: application/json" \
  -d '{"user_id":"{user-id}","product_id":"{product-id}","quantity":2,"shipping_address":"Jakarta"}'

# Update order status
curl -X PUT "${API_URL}/orders/{order-id}" \
  -H "Content-Type: application/json" \
  -d '{"status":"shipped"}'
```

**Task 24 — WebSocket Real-Time Test**

Perform a real-time WebSocket end-to-end test:

| Step | Action | Expected Result |
|------|--------|-----------------|
| 1 | Connect to WebSocket API | Connection established, connection_id stored in ws_connections table |
| 2 | Send `{"action":"ping"}` | Receive `{"action":"pong","timestamp":"..."}` |
| 3 | Send `{"action":"get_connections"}` | Receive list of active connections |
| 4 | Send `{"action":"get_orders"}` | Receive list of orders from database |
| 5 | Send `{"action":"order_status_update","order_id":"{id}","status":"delivered"}` | Order updated, broadcast received by all connected clients |
| 6 | Open second WebSocket connection | Second client connects |
| 7 | Send notification from first client | Second client receives broadcast |
| 8 | Disconnect both clients | Connections removed from ws_connections table |

```bash
# Install wscat if needed
npm install -g wscat

# Connect
wscat -c "wss://{ws-api-id}.execute-api.us-west-2.amazonaws.com/prod"

# Test ping
> {"action":"ping"}
< {"action":"pong","timestamp":"2026-07-16T10:00:00Z"}

# Test get connections
> {"action":"get_connections"}
< {"connections":[{"connection_id":"...","connected_at":"..."}]}

# Test order status update (broadcasts to all)
> {"action":"order_status_update","order_id":"{order-id}","status":"delivered"}
< {"event":"order_updated","order_id":"...","new_status":"delivered"}
```

---

## 7. DELIVERABLES

### Workflow code (provided in this document — copy to your repository):

| # | File | Source |
|---|------|--------|
| 1 | `.github/workflows/test-runner.yaml` | Task 8 in this document |
| 2 | `.github/workflows/ci.yaml` | Task 18 in this document |
| 3 | `.github/workflows/deploy.yaml` | Task 19 in this document |

### Application code (provided in the repository — deploy to AWS):

| # | File | Purpose |
|---|------|---------|
| 1 | `lambda/user-api/app.py` + `Dockerfile` | User CRUD Lambda — build, push to ECR, deploy |
| 2 | `lambda/order-api/app.py` + `Dockerfile` | Order CRUD + SQS Lambda — build, push to ECR, deploy |
| 3 | `lambda/notification-worker/app.py` + `Dockerfile` | SQS → SNS worker — build, push to ECR, deploy |
| 4 | `lambda/websocket-api/app.py` + `Dockerfile` | WebSocket handler — build, push to ECR, deploy |
| 5 | `frontend/index.html` | SPA dashboard — deploy to Amplify |
| 6 | `sql/schema.sql` | Database DDL + seed data — execute on RDS |

### Infrastructure (build from scratch):

| # | Deliverable | Description |
|---|-------------|-------------|
| 1 | AWS Infrastructure | VPC, subnets, IGW, NAT GW, SGs, EC2, RDS, SQS, SNS, ECR, Lambda, API Gateway (REST + WebSocket), Amplify, Secrets Manager, CloudWatch, VPC Flow Logs |
| 2 | GitHub Self-Hosted Runners | 2 EC2 instances registered as GitHub Actions runners |
| 3 | End-to-end CI/CD Pipeline | Workflows running on self-hosted runners, auto-deploying to production |

---

## 8. EXPECTED FINAL STATE

| Resource | Expected Status |
|----------|----------------|
| VPC `devops-vpc` | Active, 4 subnets, IGW + NAT GW attached |
| EC2 Runners (2) | Running, GitHub Actions runners Online |
| RDS `devops-db` | Available, Multi-AZ, 5 tables with seed data |
| SQS Queues (3) | Active, DLQ configured with maxReceiveCount: 3 |
| SNS Topics (2) | Active, email subscriptions confirmed |
| ECR Repositories (4) | Images present with `latest` tag |
| Lambda Functions (4) | Active, VPC configured, test invocation successful |
| REST API Gateway | Stage `prod` deployed, /users, /orders, /products return 200 |
| WebSocket API Gateway | Stage `prod` deployed, ping returns pong |
| Amplify Frontend | SUCCEED deployment, dashboard accessible with 4 tabs |
| GitHub Actions Workflows | ci.yaml + deploy.yaml + test-runner.yaml committed |
| Secrets Manager | `devops/rds-credentials` active, Lambda functions updated |
| CloudWatch Dashboard | 6 widgets displaying metrics data |
| VPC Flow Logs | Enabled, log records appearing in CloudWatch Logs |

---

## 9. EVALUATION CRITERIA

| Criterion | Weight | Key Indicators |
|-----------|--------|----------------|
| Infrastructure Completeness | 20% | VPC, subnets, NAT, SG, RDS, SQS, SNS all correctly provisioned |
| CI/CD Pipeline | 20% | Self-hosted runners online, workflows functional, auto-deploy works |
| Application Functionality | 20% | CRUD operations working, WebSocket real-time events functional |
| Security | 15% | Least privilege SGs, Secrets Manager, no public DB access, VPC isolation |
| Observability | 10% | CloudWatch dashboard, VPC Flow Logs, alarms configured |
| Code Quality | 10% | Clean Dockerfiles, proper error handling, CORS configured |
| End-to-End Verification | 5% | All test scenarios pass, frontend displays live data |

---

## 10. REFERENCES

| Service | Documentation |
|---------|---------------|
| Amazon VPC | https://docs.aws.amazon.com/vpc/latest/userguide/what-is-amazon-vpc.html |
| Amazon EC2 | https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/concepts.html |
| Amazon RDS PostgreSQL | https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_PostgreSQL.html |
| Amazon SQS | https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/welcome.html |
| Amazon SNS | https://docs.aws.amazon.com/sns/latest/dg/welcome.html |
| Amazon ECR | https://docs.aws.amazon.com/AmazonECR/latest/userguide/what-is-ecr.html |
| AWS Lambda (Container) | https://docs.aws.amazon.com/lambda/latest/dg/images-create.html |
| API Gateway REST API | https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-rest-api.html |
| API Gateway WebSocket | https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api.html |
| AWS Amplify | https://docs.aws.amazon.com/amplify/latest/userguide/welcome.html |
| AWS Secrets Manager | https://docs.aws.amazon.com/secretsmanager/latest/userguide/intro.html |
| Amazon CloudWatch | https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/WhatIsCloudWatch.html |
| VPC Flow Logs | https://docs.aws.amazon.com/vpc/latest/userguide/flow-logs.html |
| GitHub Actions Self-Hosted | https://docs.github.com/en/actions/hosting-your-own-runners |
| Docker | https://docs.docker.com/get-started/ |

---

*© 2026 LKS National Competition — Cloud Computing*
