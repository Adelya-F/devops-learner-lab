# GitHub Self-Hosted Runners on AWS Learner Lab + WebSocket API

**Level**: Advanced
**Platform**: AWS Academy Learner Lab + GitHub
**Region**: us-west-2

---

## BACKGROUND

TechnoDev is a growing e-commerce platform that needs a reliable CI/CD pipeline to deploy microservices automatically. The engineering team wants to use **GitHub Actions with self-hosted runners** running on EC2 inside a private VPC, because AWS Academy Learner Lab does not provide CodePipeline or CodeBuild.

You are assigned as the DevOps Engineer to: build a VPC with public and private subnets; launch EC2 instances as GitHub Actions self-hosted runners; provision RDS PostgreSQL, SQS, SNS, ECR; deploy 4 Lambda functions (container images) — 3 behind a REST API Gateway and 1 behind WebSocket API Gateway; create GitHub Actions workflows for CI/CD; deploy a SPA frontend via AWS Amplify with real-time WebSocket support; and set up monitoring with CloudWatch and VPC Flow Logs.

---

## TASK LIST (24 Tasks)

### Phase 1: Foundation & Network (Tasks 1–4)
1. Create GitHub repository `devops-learner-lab` with branch protection and `.gitignore`.
2. Provision VPC `devops-vpc` (210.0.0.0/16) with 4 subnets (2 public, 2 private).
3. Create Internet Gateway, NAT Gateway (Elastic IP), and route tables.
4. Create 4 security groups: runners, lambda, rds, and default (least privilege).

### Phase 2: Self-Hosted Runners (Tasks 5–8)
5. Launch 2 EC2 instances (t3.medium) in private subnets with LabRole.
6. Install Docker, AWS CLI, and GitHub Actions runner on both instances.
7. Register runners to GitHub repo and verify they appear as "Online".
8. Create `test-runner.yaml` workflow that runs on self-hosted runners.

### Phase 3: Application Infrastructure (Tasks 9–13)
9. Create RDS PostgreSQL `devops-db` (db.t3.small, Multi-AZ) with 5 tables (users, products, orders, notifications, ws_connections).
10. Create 3 SQS queues: `devops-orders-queue`, `devops-notifications-queue`, `devops-dlq`.
11. Create 2 SNS topics: `devops-notifications` and `devops-alerts`.
12. Create 4 ECR repositories and push container images.
13. Deploy 4 Lambda functions (user-api, order-api, notification-worker, websocket-api) with VPC config.

### Phase 4: API Gateway & Frontend (Tasks 14–17)
14. Create API Gateway REST API `devops-api` with resources `/users`, `/orders`, and `/products` (Lambda proxy integration, deployed to a `prod` stage).
15. Create API Gateway WebSocket API `devops-ws-api` with routes `$connect`, `$disconnect`, `$default`, `sendMessage`.
16. Deploy SPA frontend to AWS Amplify `devops-frontend` with REST API + WebSocket support.
17. Verify frontend has 4 tabs: Products, Users, Orders, Real-Time (WebSocket event feed).

### Phase 5: CI/CD Pipeline (Tasks 18–19)
18. Create `ci.yaml` workflow: lint (flake8), build 4 Docker images, test 4 Lambda handlers on pull request.
19. Create `deploy.yaml` workflow: build, push 4 images to ECR, update 4 Lambda functions, deploy Amplify, smoke test.

### Phase 6: Security & Observability (Tasks 20–22)
20. Store RDS credentials in Secrets Manager `devops/rds-credentials`.
21. Create CloudWatch dashboard with Lambda and RDS metrics.
22. Enable VPC Flow Logs to CloudWatch Logs.

### Phase 7: Verification (Tasks 23–24)
23. Run end-to-end test: create user, create order, verify notification.
24. Test WebSocket real-time: connect via WebSocket, update order status, verify broadcast received.

---

## DELIVERABLES

| # | File | Description |
|---|------|-------------|
| 1 | `.github/workflows/test-runner.yaml` | Runner verification workflow |
| 2 | `.github/workflows/ci.yaml` | CI: lint + build + test on PR |
| 3 | `.github/workflows/deploy.yaml` | CD: build + push ECR + deploy 4 Lambda + Amplify |
| 4 | `lambda/user-api/app.py` | User CRUD handler (REST API) |
| 5 | `lambda/user-api/Dockerfile` | Container image definition |
| 6 | `lambda/order-api/app.py` | Order + Products handler with SQS publish (REST API) |
| 7 | `lambda/order-api/Dockerfile` | Container image definition |
| 8 | `lambda/notification-worker/app.py` | SQS-triggered SNS notifier |
| 9 | `lambda/notification-worker/Dockerfile` | Container image definition |
| 10 | `lambda/websocket-api/app.py` | WebSocket API handler (real-time events) |
| 11 | `lambda/websocket-api/Dockerfile` | Container image definition |
| 12 | `frontend/index.html` | SPA dashboard (Tailwind CSS + DaisyUI, 4 tabs with WebSocket) |
| 13 | `sql/schema.sql` | Database DDL (5 tables) + seed data |

---

*LKS Nasional 2026 · Cloud Computing · GitHub Self-Hosted Runners + WebSocket API*
*© 2026 Cloud Computing Competition*